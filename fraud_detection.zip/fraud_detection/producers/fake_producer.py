import time
import random
from confluent_kafka import SerializingProducer
from confluent_kafka.serialization import StringSerializer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.avro import AvroSerializer
from faker import Faker
fake = Faker()

def delivery_report(err, msg):
 
    if err is not None:
        print("Delivery failed for record {}: {}".format(msg.key(), err))
        return
    print('Record {} successfully produced to {} [{}] at offset {}'.format(
        msg.key(), msg.topic(), msg.partition(), msg.offset()))
# 1. Setup Configuration
conf = {
    'bootstrap.servers': 'pkc-56d1g.eastus.azure.confluent.cloud:9092',
    'sasl.mechanisms': 'PLAIN',
    'security.protocol': 'SASL_SSL',
    'sasl.username': 'EVXRHDPMZRRNKC3W',
    'sasl.password': 'cfltV03brF0KLyoVeLKIBex+7zZlkzk/uDfiao9l4CPOTAmgkcwbzdUa/tOI+Utw'
}

schema_registry_conf = {'url': 'https://psrc-4n808m2.eastus.azure.confluent.cloud', 
                        'basic.auth.user.info': 'M3ZVWPG74MWZH34Z:cflt91DM1AUHfzyl1Cc09picmMvrD5fQgJfS4xp8h7NCaYw+30XfTmqTXELrLyRQ'}

# 2. Setup Serializers
sr_client = SchemaRegistryClient(schema_registry_conf)
subject_name = 'transactions-value'
transaction_schema = sr_client.get_latest_version(subject_name).schema.schema_str

avro_serializer = AvroSerializer(sr_client, transaction_schema)
string_serializer = StringSerializer('utf_8')
producer = SerializingProducer({
    **conf,
    'key.serializer': string_serializer,
    'value.serializer': avro_serializer,
    'acks': 'all'
})

user_pool = [f"user_{i}" for i in range(1000)]

print("Producing Avro-encoded transactions...")
# 3. Generate Data
try:
        while True:
            user_id = random.choice(user_pool)
            
            tx = {
                "transaction_id": fake.uuid4(),
                "user_id": user_id,
                "amount": round(random.uniform(10.0, 5000.0), 2),
                "lat": 40.7128,
                "lon": -74.0060,
                "timestamp": int(time.time() * 1000)
            }

            # 4. PRODUCE TO KAFKA
            # The data is converted to binary Avro format here
            producer.produce(topic='transactions', key=user_id, value=tx,on_delivery=delivery_report)
            producer.flush()
            
            # Simulate Fraud (Teleportation)
            if random.random() > 0.95:
                fraud_tx = tx.copy()
                fraud_tx["lat"], fraud_tx["lon"] = 48.8566, 2.3522 # Paris
                producer.produce(topic='transactions', key=user_id, value=fraud_tx,on_delivery=delivery_report)
                producer.flush()

            producer.poll(0)
            time.sleep(0.5)

except KeyboardInterrupt:
        print("Stopping...")
finally:
        producer.flush()

