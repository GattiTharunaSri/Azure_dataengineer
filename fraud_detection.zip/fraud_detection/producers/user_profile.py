import time
import random
from faker import Faker
from confluent_kafka import SerializingProducer
from confluent_kafka.serialization import StringSerializer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.avro import AvroSerializer

fake = Faker()

conf = {
    'bootstrap.servers': 'pkc-56d1g.eastus.azure.confluent.cloud:9092',
    'sasl.mechanisms': 'PLAIN',
    'security.protocol': 'SASL_SSL',
    'sasl.username': 'EVXRHDPMZRRNKC3W',
    'sasl.password': 'cfltV03brF0KLyoVeLKIBex+7zZlkzk/uDfiao9l4CPOTAmgkcwbzdUa/tOI+Utw'
}

schema_registry_conf = {'url': 'https://psrc-4n808m2.eastus.azure.confluent.cloud', 
                        'basic.auth.user.info': 'M3ZVWPG74MWZH34Z:cflt91DM1AUHfzyl1Cc09picmMvrD5fQgJfS4xp8h7NCaYw+30XfTmqTXELrLyRQ'}

# 2. Setup Serializers
def produce_user_profiles(count=500):
    sr_client = SchemaRegistryClient(schema_registry_conf)
    subject_name = 'user_profiles-value'
    transaction_schema = sr_client.get_latest_version(subject_name).schema.schema_str

    avro_serializer = AvroSerializer(sr_client, transaction_schema)
    string_serializer = StringSerializer('utf_8')
    producer = SerializingProducer({
        **conf,
        'key.serializer': string_serializer,
        'value.serializer': avro_serializer
   })

    print(f"Populating user_profiles for {count} users...")

    for i in range(count):
        user_id = f"user_{i}"
        
        # Mapping to your schema fields
        profile_data = {
            "user_id": user_id,
            "home_country": fake.country(),
            "daily_limit": float(random.randint(1000, 10000)) # Random limit between 1k and 10k
        }

        producer.produce(
            topic='user_profiles', 
            key=user_id, 
            value=profile_data
        )

    producer.flush()
    print("User profiles successfully synced to Kafka.")

if __name__ == "__main__":
    produce_user_profiles(500)