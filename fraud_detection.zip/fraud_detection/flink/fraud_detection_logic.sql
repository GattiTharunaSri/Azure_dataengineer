INSERT INTO fraud_alerts_final
SELECT 
    user_id, 
    'IMPOSSIBLE_TRAVEL_DETECTED' AS alert_type, 
    CAST(UNIX_TIMESTAMP() * 1000 AS BIGINT) AS alert_timestamp
FROM (
    SELECT t1.user_id
    FROM transactions t1
    JOIN transactions t2 ON t1.user_id = t2.user_id
    WHERE t2.`timestamp` > t1.`timestamp` 
      AND TO_TIMESTAMP_LTZ(t2.`timestamp`, 3) <= TO_TIMESTAMP_LTZ(t1.`timestamp`, 3) + INTERVAL '10' MINUTE
      AND (ABS(t1.lat - t2.lat) > 5 OR ABS(t1.lon - t2.lon) > 5)
);