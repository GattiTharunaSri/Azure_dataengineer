from confluent_kafka import Consumer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.avro import AvroDeserializer

# 1. Connect to your Azure Schema Registry
sr_conf = {
    'url': 'https://psrc-4n808m2.eastus.azure.confluent.cloud', 
    'basic.auth.user.info': 'M3ZVWPG74MWZH34Z:cflt91DM1AUHfzyl1Cc09picmMvrD5fQgJfS4xp8h7NCaYw+30XfTmqTXELrLyRQ'
}
sr_client = SchemaRegistryClient(sr_conf)
avro_deserializer = AvroDeserializer(sr_client)

# 2. Use your Azure Cluster credentials
conf = {
    'bootstrap.servers': 'pkc-56d1g.eastus.azure.confluent.cloud:9092',
    'sasl.mechanisms': 'PLAIN',
    'security.protocol': 'SASL_SSL',
    'sasl.username': 'EVXRHDPMZRRNKC3W',
    'sasl.password': 'cfltV03brF0KLyoVeLKIBex+7zZlkzk/uDfiao9l4CPOTAmgkcwbzdUa/tOI+Utw',
    'group.id': 'fraud-final-consumer',
    'auto.offset.reset': 'earliest'
}

consumer = Consumer(conf)
consumer.subscribe(['fraud_alerts_final'])

print("🛡️ SentinelStream Action Layer: Active")

try:
    while True:
        msg = consumer.poll(1.0)
        if msg is None: continue
        
        # Deserialization: Binary -> Python Dictionary
        alert = avro_deserializer(msg.value(), None)
        
        print(f"🚨 FRAUD ACTION: User {alert['user_id']} flagged for {alert['alert_type']}.")
        print(f"Timestamp: {alert['alert_timestamp']}")
except KeyboardInterrupt:
    pass
finally:
    consumer.close()